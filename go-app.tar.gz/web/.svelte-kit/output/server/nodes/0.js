

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.B63xZy-9.js","_app/immutable/chunks/BH_hMJzF.js","_app/immutable/chunks/O_Zr8CAz.js"];
export const stylesheets = ["_app/immutable/assets/0.DME6Kuj-.css"];
export const fonts = [];
