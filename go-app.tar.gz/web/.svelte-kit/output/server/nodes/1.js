

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.LtwD1kpb.js","_app/immutable/chunks/BH_hMJzF.js","_app/immutable/chunks/O_Zr8CAz.js","_app/immutable/chunks/CggVhAhQ.js","_app/immutable/chunks/D8cmA2oX.js","_app/immutable/chunks/B48aBk-J.js","_app/immutable/chunks/DLBhWDLQ.js"];
export const stylesheets = [];
export const fonts = [];
