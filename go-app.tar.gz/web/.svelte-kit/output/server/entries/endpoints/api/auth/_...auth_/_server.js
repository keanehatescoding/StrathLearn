import { a as auth } from "../../../../../chunks/auth.js";
const GET = auth.handler;
const POST = auth.handler;
const PUT = auth.handler;
const DELETE = auth.handler;
export {
  DELETE,
  GET,
  POST,
  PUT
};
