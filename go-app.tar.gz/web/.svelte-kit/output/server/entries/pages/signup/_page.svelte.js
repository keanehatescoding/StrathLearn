import { m as sanitize_props, n as spread_props, o as slot, u as attr, l as escape_html, j as pop, p as push } from "../../../chunks/index.js";
import { createAuthClient } from "better-auth/svelte";
import "../../../chunks/client.js";
import { I as Icon } from "../../../chunks/Icon.js";
function Key($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4"
      }
    ],
    ["path", { "d": "m21 2-9.6 9.6" }],
    [
      "circle",
      { "cx": "7.5", "cy": "15.5", "r": "5.5" }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "key" },
    $$sanitized_props,
    {
      iconNode,
      children: ($$payload2) => {
        $$payload2.out += `<!---->`;
        slot($$payload2, $$props, "default", {});
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
}
function Mail($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "rect",
      {
        "width": "20",
        "height": "16",
        "x": "2",
        "y": "4",
        "rx": "2"
      }
    ],
    [
      "path",
      {
        "d": "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "mail" },
    $$sanitized_props,
    {
      iconNode,
      children: ($$payload2) => {
        $$payload2.out += `<!---->`;
        slot($$payload2, $$props, "default", {});
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
}
function Sparkles($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"
      }
    ],
    ["path", { "d": "M20 3v4" }],
    ["path", { "d": "M22 5h-4" }],
    ["path", { "d": "M4 17v2" }],
    ["path", { "d": "M5 18H3" }]
  ];
  Icon($$payload, spread_props([
    { name: "sparkles" },
    $$sanitized_props,
    {
      iconNode,
      children: ($$payload2) => {
        $$payload2.out += `<!---->`;
        slot($$payload2, $$props, "default", {});
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
}
function User($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    [
      "path",
      {
        "d": "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"
      }
    ],
    ["circle", { "cx": "12", "cy": "7", "r": "4" }]
  ];
  Icon($$payload, spread_props([
    { name: "user" },
    $$sanitized_props,
    {
      iconNode,
      children: ($$payload2) => {
        $$payload2.out += `<!---->`;
        slot($$payload2, $$props, "default", {});
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
}
const authClient = createAuthClient({
  baseURL: "http://localhost:5173/",
  credentials: "include"
});
const { signIn, signUp, useSession } = authClient;
function _page($$payload, $$props) {
  push();
  useSession();
  let email = "";
  let password = "";
  let username = "";
  let loading = false;
  $$payload.out += `<div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-100 to-amber-100"><div class="max-w-md w-full space-y-8 p-8 bg-gradient-to-br from-amber-50 to-purple-100 rounded-lg border border-amber-200 shadow-lg"><div>`;
  Sparkles($$payload, {
    class: "h-12 w-12 mx-auto mb-4 text-purple-700"
  });
  $$payload.out += `<!----> <h2 class="mt-2 text-center text-3xl font-serif font-bold text-purple-900">Join the Magical Order</h2> <p class="mt-2 text-center text-amber-800">Already a member of our mystical circle? <a href="/signin" class="font-medium text-amber-700 hover:text-amber-800 underline">Sign in with your runes</a></p></div> <form class="mt-8 space-y-6"><div class="space-y-4"><div><label for="username" class="block text-amber-800 font-medium mb-2">Your Magical Title</label> <div class="relative"><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">`;
  User($$payload, { class: "h-5 w-5 text-amber-700" });
  $$payload.out += `<!----></div> <input id="username" type="text"${attr("value", username)} placeholder="Wizard Eldritch" required class="pl-10 w-full bg-amber-50 border border-amber-300 text-amber-900 rounded-lg p-3 focus:ring-2 focus:ring-purple-600 focus:border-transparent"></div></div> <div><label for="email" class="block text-amber-800 font-medium mb-2">Your Mystical Address</label> <div class="relative"><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">`;
  Mail($$payload, { class: "h-5 w-5 text-amber-700" });
  $$payload.out += `<!----></div> <input id="email" type="email"${attr("value", email)} placeholder="wizard@eldoria.realm" required class="pl-10 w-full bg-amber-50 border border-amber-300 text-amber-900 rounded-lg p-3 focus:ring-2 focus:ring-purple-600 focus:border-transparent"></div></div> <div><label for="password" class="block text-amber-800 font-medium mb-2">Create Your Arcane Seal</label> <div class="relative"><div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">`;
  Key($$payload, { class: "h-5 w-5 text-amber-700" });
  $$payload.out += `<!----></div> <input id="password" type="password"${attr("value", password)} placeholder="At least 8 mystical characters" required minlength="8" class="pl-10 w-full bg-amber-50 border border-amber-300 text-amber-900 rounded-lg p-3 focus:ring-2 focus:ring-purple-600 focus:border-transparent"></div> <p class="mt-1 text-xs text-amber-700">Your seal must contain at least 8 mystical symbols for proper enchantment</p></div></div> <div><button type="submit"${attr("disabled", loading, true)} class="w-full bg-purple-800 hover:bg-purple-900 text-amber-100 font-medium px-6 py-3 rounded-lg transition-colors border border-purple-700 flex items-center justify-center space-x-2 disabled:opacity-50">`;
  Sparkles($$payload, { size: 18 });
  $$payload.out += `<!----> <span>${escape_html("Create Magical Account")}</span></button></div> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></form></div></div>`;
  pop();
}
export {
  _page as default
};
