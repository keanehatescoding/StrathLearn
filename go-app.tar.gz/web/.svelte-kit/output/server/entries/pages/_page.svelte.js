import { m as sanitize_props, n as spread_props, o as slot, q as ensure_array_like, t as head, u as attr, l as escape_html, j as pop, p as push } from "../../chunks/index.js";
import { I as Icon } from "../../chunks/Icon.js";
function Code($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["polyline", { "points": "16 18 22 12 16 6" }],
    ["polyline", { "points": "8 6 2 12 8 18" }]
  ];
  Icon($$payload, spread_props([
    { name: "code" },
    $$sanitized_props,
    {
      iconNode,
      children: ($$payload2) => {
        $$payload2.out += `<!---->`;
        slot($$payload2, $$props, "default", {});
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
}
function Loader($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const iconNode = [
    ["path", { "d": "M12 2v4" }],
    ["path", { "d": "m16.2 7.8 2.9-2.9" }],
    ["path", { "d": "M18 12h4" }],
    ["path", { "d": "m16.2 16.2 2.9 2.9" }],
    ["path", { "d": "M12 18v4" }],
    ["path", { "d": "m4.9 19.1 2.9-2.9" }],
    ["path", { "d": "M2 12h4" }],
    ["path", { "d": "m4.9 4.9 2.9 2.9" }]
  ];
  Icon($$payload, spread_props([
    { name: "loader" },
    $$sanitized_props,
    {
      iconNode,
      children: ($$payload2) => {
        $$payload2.out += `<!---->`;
        slot($$payload2, $$props, "default", {});
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
}
function _page($$payload, $$props) {
  push();
  let challenges = {};
  const each_array = ensure_array_like(Object.entries(challenges));
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>StrathLearn - Code Challenge Platform</title>`;
    $$payload2.out += `<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/github-dark.min.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/material-palenight.min.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/dracula.min.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/foldgutter.min.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/hint/show-hint.min.css"> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/scroll/simplescrollbars.min.css"> <link rel="preconnect" href="https://fonts.googleapis.com"> <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin=""> <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&amp;family=Inter:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet"> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/edit/closebrackets.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/edit/matchbrackets.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/foldcode.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/foldgutter.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/brace-fold.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/hint/show-hint.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/hint/anyword-hint.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/search/searchcursor.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/search/match-highlighter.min.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/scroll/simplescrollbars.min.js"><\/script>`;
  });
  $$payload.out += `<div class="min-h-screen bg-slate-50 flex flex-col font-sans"><header class="bg-gradient-to-r from-indigo-900 to-blue-800 text-white shadow-lg"><div class="container mx-auto px-4 py-4 flex justify-between items-center"><div class="text-2xl font-bold tracking-tight flex items-center gap-2">`;
  Code($$payload, { class: "h-6 w-6 text-cyan-300" });
  $$payload.out += `<!----> StrathLearn</div> <nav><ul class="flex space-x-8"><li><a href="/" class="hover:text-cyan-300 font-medium text-cyan-100 transition-colors duration-200 py-2 flex items-center border-b-2 border-cyan-400">Challenges</a></li> <li><a href="#" class="hover:text-cyan-300 text-white/80 transition-colors duration-200 py-2 flex items-center border-b-2 border-transparent">Leaderboard</a></li> <li><a href="#" class="hover:text-cyan-300 text-white/80 transition-colors duration-200 py-2 flex items-center border-b-2 border-transparent">About</a></li></ul></nav></div></header> <main class="flex-grow"><div class="container mx-auto px-4 py-8"><div class="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4"><div><label for="challenge-select" class="block text-sm font-medium text-slate-700 mb-2">Select Challenge:</label> <select id="challenge-select" class="block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white transition-all duration-200"><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let [id, challenge] = each_array[$$index];
    $$payload.out += `<option${attr("value", id)}>${escape_html(challenge.title)}</option>`;
  }
  $$payload.out += `<!--]--></select></div> <div><label for="theme-select" class="block text-sm font-medium text-slate-700 mb-2">Editor Theme:</label> <select id="theme-select" class="block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white transition-all duration-200"><option value="github-dark">GitHub Dark</option><option value="material-palenight">Material Palenight</option><option value="dracula">Dracula</option></select></div></div> `;
  {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<div class="text-center py-16 bg-white rounded-xl shadow-md border border-slate-200">`;
    Loader($$payload, {
      class: "h-16 w-16 mx-auto text-slate-400 mb-4 animate-spin"
    });
    $$payload.out += `<!----> <p class="text-xl text-slate-600">Loading challenge...</p></div>`;
  }
  $$payload.out += `<!--]--></div></main> <footer class="bg-slate-800 text-white/80 py-6 mt-8"><div class="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center"><div class="flex items-center gap-2 mb-4 md:mb-0">`;
  Code($$payload, { class: "h-5 w-5 text-blue-400" });
  $$payload.out += `<!----> <span class="font-semibold text-white">StrathLearn</span></div> <div class="flex items-center space-x-6 mt-4 md:mt-0"><a href="#" class="text-white/80 hover:text-white transition-colors duration-200">Terms</a> <a href="#" class="text-white/80 hover:text-white transition-colors duration-200">Privacy</a> <a href="#" class="text-white/80 hover:text-white transition-colors duration-200">Help</a></div></div></footer></div>`;
  pop();
}
export {
  _page as default
};
