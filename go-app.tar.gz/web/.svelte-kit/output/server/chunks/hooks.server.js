import { a as auth } from "./auth.js";
import { svelteKitHandler } from "better-auth/svelte-kit";
async function handle({ event, resolve }) {
  return svelteKitHandler({ event, resolve, auth });
}
export {
  handle
};
