import { auth } from '$lib/auth.js'

export const GET = auth.handler
export const POST = auth.handler
export const PUT = auth.handler
export const DELETE = auth.handler