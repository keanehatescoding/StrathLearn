<script lang="ts">
    import  {Button}  from "$lib/components/ui/button/index.js";
</script>
<div>
    <Button variant="outline">Button</Button>
</div>